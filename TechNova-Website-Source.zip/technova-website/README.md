# TechNova — Technology Landing Page

A responsive, single-page technology website built with HTML5, CSS3, JavaScript, jQuery, and Bootstrap 5.

## Files
- `index.html` — page structure and CDN links
- `style.css` — dark futuristic theme, responsive layout, and animations
- `script.js` — navigation, scroll effects, and demo form validation

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. An internet connection is required for Bootstrap, jQuery, Google Fonts, and Font Awesome CDNs.

Optional: use the VS Code Live Server extension and open `index.html` with Live Server.

## Before submission
- Replace `hello@technova.example` with your own contact email if needed.
- The contact form is front-end demonstration only. It validates input but does not send or store messages.
- Update social links to your own profiles if required.
- Test the site on desktop and mobile.

## Publish on GitHub
1. Sign in at https://github.com/ and create a **public** repository named `technova-website`.
2. Upload `index.html`, `style.css`, and `script.js` to the repository root (or use Git).
3. Commit the files.

## Deploy on Netlify (recommended for this static site)
1. Sign in at https://www.netlify.com/.
2. Choose **Add new site** → **Import an existing project**.
3. Connect GitHub and authorize Netlify.
4. Select `technova-website`.
5. For a plain static site, leave **Build command** blank and set **Publish directory** to `.` (the repository root).
6. Click **Deploy site**.
7. Open the generated `https://...netlify.app` URL and test every navigation link and the contact form.
8. Submit both URLs:
   - GitHub repository: `https://github.com/YOUR-USERNAME/technova-website`
   - Live website: `https://YOUR-SITE.netlify.app`

## Alternative: Netlify manual deploy
Drag the folder containing `index.html`, `style.css`, and `script.js` into Netlify's manual deploy area. For future updates, GitHub-connected deployment is easier.

## Railway
Railway can deploy static sites too, but Netlify is simpler for this no-build static website. If using Railway, connect the GitHub repository and follow its current static-site deployment flow.
