$(function () {
  // Smooth navigation and close the mobile menu after a selection.
  $('.navbar-nav .nav-link, .navbar-nav .btn, .scroll-cue').on('click', function () {
    const menu = document.getElementById('mainNav');
    if (menu && menu.classList.contains('show')) {
      bootstrap.Collapse.getOrCreateInstance(menu).hide();
    }
  });

  // Highlight the current section in the navigation.
  const sections = $('main section[id]');
  $(window).on('scroll', function () {
    const scrollPosition = $(this).scrollTop() + 130;
    sections.each(function () {
      const top = $(this).offset().top;
      const bottom = top + $(this).outerHeight();
      if (scrollPosition >= top && scrollPosition < bottom) {
        const id = $(this).attr('id');
        $('.navbar-nav .nav-link').removeClass('active');
        $('.navbar-nav .nav-link[href="#' + id + '"]').addClass('active');
      }
    });
    $('#backToTop').toggleClass('visible', $(this).scrollTop() > 450);
  });

  // Reveal cards and sections as they enter the viewport.
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
  } else {
    $('.reveal').addClass('in-view');
  }

  // Front-end demo form validation. No message is transmitted.
  $('#contactForm').on('submit', function (event) {
    event.preventDefault();
    const name = $('#name').val().trim();
    const email = $('#email').val().trim();
    const message = $('#message').val().trim();
    const feedback = $('#formFeedback');
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!name || !email || !message) {
      feedback.text('Please complete all fields before submitting.');
      return;
    }
    if (!emailPattern.test(email)) {
      feedback.text('Please enter a valid email address.');
      $('#email').trigger('focus');
      return;
    }
    feedback.text('Thanks, ' + name + '! Your demo message passed validation.');
    this.reset();
  });

  $('#backToTop').on('click', function () {
    $('html, body').animate({ scrollTop: 0 }, 550);
  });

  $('#year').text(new Date().getFullYear());
});
